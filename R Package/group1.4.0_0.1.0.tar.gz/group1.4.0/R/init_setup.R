.onAttach <- function(libname, pkgname) {
    packageStartupMessage("Welcome to the package group1.4.0! Your journey through college search starts here. Please read the documentation to get the most of this plethora of incredible functions and data!")
}
